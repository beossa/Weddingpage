# Website Tiệc Cưới Tại Nhà

Website trưng bày dịch vụ tiệc cưới tại nhà với giao diện đẹp mắt và dễ sử dụng.

## 📁 Cấu Trúc File

```
├── wedding-website.html    # Trang chủ
├── styles.css             # File CSS chung cho tất cả các trang
├── main.js                # File JavaScript chung
├── banghe.html           # Trang chi tiết Bàn Ghế
├── cong.html             # Trang chi tiết Cổng Cưới
├── ghedua.html           # Trang chi tiết Ghế Dựa
├── giatien.html          # Trang chi tiết Giá Tiền
├── rap.html              # Trang chi tiết Rạp Cưới
├── sankhau-bg.html       # Trang chi tiết Sân Khấu & Background
└── background.html       # Trang chi tiết Background Trang Trí
```

## ✨ Tính Năng

### Trang Chủ (wedding-website.html)
- Hero section với animation đẹp mắt
- 7 dịch vụ chính: Bàn Ghế, Cổng Cưới, Ghế Dựa, Giá Tiền, Rạp Cưới, Sân Khấu & Background, Background Trang Trí
- Gallery hiển thị hình ảnh
- Thông tin liên hệ
- Responsive trên mọi thiết bị

### Trang Chi Tiết (7 trang service)
Mỗi trang service có:
- Header với menu điều hướng
- Nút "Quay Lại" về trang chủ
- Mô tả chi tiết về dịch vụ
- Grid hiển thị 6-9 sản phẩm với:
  - Hình ảnh (placeholder, có thể thay bằng ảnh thật)
  - Tên sản phẩm
  - Mô tả chi tiết
  - Giá tiền
  - Tính năng nổi bật
  - Nút "Liên Hệ Đặt Hàng"
- Thông tin liên hệ ở cuối trang

## 🎨 Màu Sắc Chính

- Primary: #d4a574 (Vàng đồng)
- Secondary: #c48d5f (Vàng đồng đậm)
- Background: Gradient pastel nhẹ nhàng
- Text: #333 (Đen nhạt)

## 🔧 Cách Tùy Chỉnh

### 1. Thay Đổi Thông Tin Liên Hệ

Tìm và sửa trong tất cả các file HTML:
```html
<span>0123 456 789</span>          <!-- Số điện thoại -->
<span>contact@tieccuoi.vn</span>   <!-- Email -->
<span>TP. Hồ Chí Minh, Việt Nam</span>  <!-- Địa chỉ -->
```

### 2. Thay Đổi Màu Sắc

Mở file `styles.css` và tìm:
```css
#d4a574  /* Màu vàng đồng chính */
#c48d5f  /* Màu vàng đồng đậm */
```
Thay bằng mã màu mới của bạn.

### 3. Thêm Hình Ảnh Thật

**Cách 1: Trong trang detail**
Thay thế:
```html
<div class="product-image">💺</div>
```
Bằng:
```html
<div class="product-image">
    <img src="duong-dan-anh.jpg" alt="Mô tả sản phẩm">
</div>
```

**Cách 2: Trong gallery trang chủ**
Thay thế:
```html
<div class="gallery-placeholder">
    🍽️
    <span>Tiệc Buffet</span>
</div>
```
Bằng:
```html
<img src="duong-dan-anh.jpg" alt="Tiệc Buffet" style="width:100%; height:100%; object-fit:cover;">
```

### 4. Thêm/Sửa Sản Phẩm

Copy một khối `.product-card` và sửa nội dung:
```html
<div class="product-card fade-in">
    <div class="product-image">🆕</div>
    <div class="product-info">
        <h3>Tên Sản Phẩm Mới</h3>
        <p>Mô tả chi tiết sản phẩm...</p>
        <div class="product-price">500.000đ / bộ</div>
        <ul class="product-features">
            <li>Tính năng 1</li>
            <li>Tính năng 2</li>
            <li>Tính năng 3</li>
        </ul>
        <a href="wedding-website.html#contact" class="contact-button">Liên Hệ Đặt Hàng</a>
    </div>
</div>
```

### 5. Thay Đổi Giá Tiền

Tìm và sửa:
```html
<div class="product-price">500.000đ / bộ</div>
```

## 📱 Responsive

Website tự động responsive trên:
- Desktop (>768px)
- Tablet (768px)
- Mobile (<768px)

## 🚀 Cách Sử Dụng

1. Mở file `wedding-website.html` bằng trình duyệt
2. Click vào từng service để xem chi tiết
3. Dùng nút "Quay Lại" hoặc menu để điều hướng

## 💡 Gợi Ý Phát Triển Thêm

1. **Thêm Form Liên Hệ**: Tạo form để khách hàng gửi yêu cầu trực tiếp
2. **Thêm Slider**: Dùng Swiper.js cho gallery ảnh đẹp hơn
3. **Tích Hợp CMS**: Dùng WordPress hoặc Strapi để quản lý nội dung dễ dàng
4. **Thêm Admin Panel**: Tạo trang admin để cập nhật sản phẩm không cần code
5. **SEO**: Thêm meta tags, sitemap.xml
6. **Analytics**: Tích hợp Google Analytics
7. **Chat**: Thêm Messenger hoặc Zalo chat

## 📞 Hỗ Trợ

Nếu cần hỗ trợ, vui lòng liên hệ qua email hoặc điện thoại đã cung cấp trong website.

---
**Phiên bản**: 1.0  
**Ngày tạo**: 2024  
**Công nghệ**: HTML5, CSS3, JavaScript (Vanilla)
